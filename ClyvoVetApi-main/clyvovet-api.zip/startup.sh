#!/bin/sh
exec dotnet ./ClyvoVetApi.dll
